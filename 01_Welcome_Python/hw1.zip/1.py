a = 'hello'
b = 'world!'
print(f"{a}, {b}")
num1 = int(input('Введите число - '))
num2 = int(input('Введите число - '))
print(f"Вы ввели числа {num1} и {num2}")
word = input("Enter any word: ")
print(f"{word} - отличный выбор!")
